package worker

import (
	"time"
	"log"
)

type Worker interface {
	Task()
}

type Pool struct {
	work chan Worker
}

func New(goroutinesNum int) *Pool {
	p := Pool{
		work: make(chan Worker),
	}
	for i := 0; i < goroutinesNum; i++ {
		go func() {
			for w := range p.work {
				w.Task()
			}
		}()
	}
	return &p
}

func (p *Pool) Run(w Worker) {
	p.work <- w
}

func TestWorker() {
	p := New(2)
	names := []Name {
		"zhangyang1",
		"zhangyang2",
		"limeng1",
		"limeng2",
	}
	for i := 0; i < 2; i++ {
		for _, name := range names {
			p.Run(&name)
		}
	}
}
type Name string
func(n *Name) Task(){
	log.Println(*n)
	time.Sleep(1e9)
}

func init(){
	log.SetPrefix("test worker:")
	log.SetFlags(log.Ldate | log.Llongfile | log.Lmicroseconds | log.Ltime)
}