package runner

import (
	"os/signal"
	"time"
	"os"
	"errors"
)

type Runner struct {
	complete chan error
	interrupt chan os.Signal
	timeout <-chan time.Time
	tasks [] func(int)
}

var InterError = errors.New("inter")
var TimeOutError = errors.New("timeout")

func New(d time.Duration) *Runner{
	return &Runner{
		complete:make(chan error),
		interrupt:make(chan os.Signal, 1),
		timeout:time.After(d),

	}
}

func (r *Runner) Add(tasks ...func(int)) {
	r.tasks = append(r.tasks, tasks...)
}

func (r *Runner) Start() error {
	signal.Notify(r.interrupt, os.Interrupt)
	go func(){
		for index, task := range r.tasks {
			if r.isInterrupt() {
				r.complete <- InterError
				return
			}
			task(index)
		}
		r.complete <- nil
	}()
	select {
	case err := <- r.complete:
		return  err
		case <-r.timeout:
			return TimeOutError

	}
	return nil
}
func (r* Runner) isInterrupt() bool {
	select {
	case <-r.interrupt:
		signal.Stop(r.interrupt)
		return true
	default:
		return false
	}
}
