package main

import (
	"flag"
	"fmt"
	"os"
	"learngo/runner"
	"time"
	"learngo/worker"
	"container/list"
)

var (
	h bool

	v, V bool
	t, T bool
	q    *bool

	s string
	p string
	c string
	g string
)

func init() {
	flag.BoolVar(&h, "h", false, "this help")

	flag.BoolVar(&v, "v", false, "show version and exit")
	flag.BoolVar(&V, "V", false, "show version and configure options then exit")

	flag.BoolVar(&t, "t", false, "test configuration and exit")
	flag.BoolVar(&T, "T", false, "test configuration, dump it and exit")

	// 另一种绑定方式
	q = flag.Bool("q", false, "suppress non-error messages during configuration testing")

	// 注意 `signal`。默认是 -s string，有了 `signal` 之后，变为 -s signal
	flag.StringVar(&s, "s", "", "send `signal` to a master process: stop, quit, reopen, reload")
	flag.StringVar(&p, "p", "/usr/local/nginx/", "set `prefix` path")
	flag.StringVar(&c, "c", "conf/nginx.conf", "set configuration `file`")
	flag.StringVar(&g, "g", "conf/nginx.conf", "set global `directives` out of configuration file")

	// 改变默认的 Usage
	flag.Usage = usage
}

func usage() {
	fmt.Fprintf(os.Stderr, `nginx version: nginx/1.10.0
Usage: nginx [-hvVtTq] [-s signal] [-c filename] [-p prefix] [-g directives]

Options:
`)
	flag.PrintDefaults()
}

func InitFlag() {
	flag.BoolVar(&h, "h", false, "help")
}

func f1(in chan int) {
	fmt.Println(<-in)
}

//main 入口
func main() {
	l := list.New()
	l.PushBack(123)
	l.PushBack(24)
	fmt.Println(l.Front().Value.(int) + l.Back().Value.(int))
	fmt.Println(l.Back().Value)
	r := runner.New(time.Second * 10)
	r.Add(runTask, runTask, runTask)
	err := r.Start()
	if err != nil {
		switch err {
		case runner.TimeOutError:
			fmt.Println("timeout:", err)
		case runner.InterError:
			fmt.Println("intererror::", err)
		}
	}
	fmt.Println("ended")

	worker.TestWorker()


}
func runTask(i int) {
	fmt.Println(i)
	time.Sleep(time.Second * time.Duration(i))
}
