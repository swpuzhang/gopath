package rwtest
import (
	"bufio"
	"crypto/sha1"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"os"
)

func Even(i int) bool {        // Exported function
	return i%2 == 0
}
func Odd(i int) bool {        // Exported function
	return i%2 != 0
}

func TestRead(){
	fmt.Println("请输入两个单词:")
	var firstName , lastName string
	var i1, i2, i3 int
	if num, err := fmt.Scanln(&firstName, &lastName); (err != nil) || num != 2 {
		fmt.Println("input err")
		return
	}

	fmt.Printf("Hi, %s %s!\n", firstName, lastName)
	fmt.Sscanf("12 13 14", "%d %d %d", &i1, &i2, &i3)
	fmt.Println(i1, i2, i3)

}

func TestBufio() {
	reader := bufio.NewReader(os.Stdin)
	if input, err := reader.ReadString('\n'); err == nil {
		fmt.Printf("The input was: %s\n", input)
	}
}

func TestFileRead() {
	inputFile, err := os.Open("1.txt")
	if err == nil {
		defer inputFile.Close()
		reader :=  bufio.NewReader(inputFile)
		for {
			inputString, readerError := reader.ReadString('\n')
			fmt.Printf("The input was: %s", inputString)
			if readerError == io.EOF {
				return
			}
		}
	}
	fmt.Println("open file 1.txt error:", err)
}

func ReadAll() {
	buf, err := ioutil.ReadFile("1.txt")
	if err != nil {
		fmt.Fprintf(os.Stderr, "File Error: %s\n", err)

	}
	fmt.Println(buf)
	err = ioutil.WriteFile("2.txt", buf, 0777)
	if err != nil {
		fmt.Println(err.Error())
	}
}

func Cat(r *bufio.Reader) {
	for {
		buf, err := r.ReadBytes('\n')
		buf1 := bufio.NewWriter(os.Stdout)

		if err == io.EOF {
			break
		}
		fmt.Fprintf(buf1, "%s", buf)
	}
	return
}

type Address struct {
	Type, City, Country    string
}

type VCard struct {
	FirstName string
	LastName  string
	Addresses []*Address
	Remark    string
}

func TestJson() {
	pa := &Address{"private", "Aartselaar", "Belgium"}
	wa := &Address{"work", "Boom", "Belgium"}
	vc := VCard{"Jan", "Kersschot", []*Address{pa, wa}, "none"}
	js, _ := json.Marshal(vc)
	fmt.Printf("JSON format: %s", js)
	file, _ := os.OpenFile("vcard.json", os.O_CREATE|os.O_WRONLY, 0666)
	defer file.Close()
	enc := json.NewEncoder(file)
	err := enc.Encode(vc)
	if err != nil {
		log.Println("Error in encoding json")
	}
}

func TestSha1() {
	hasher := sha1.New()
	hasher.Write([]byte("test"))
	fmt.Println("\nResult:", hasher.Sum(nil))
	fmt.Printf("Result: %x\n", hasher.Sum(nil))
	fmt.Printf("Result: %d\n", hasher.Sum(nil))
}