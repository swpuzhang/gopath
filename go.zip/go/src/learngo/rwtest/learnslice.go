package rwtest

import (
	"fmt"
)

func SliceTest() {
	s := []int{10, 20, 30, 40, 50}
	news := s[1:3]
	news = append(news, 60)
	fmt.Println(s)
	news = append(news, 70)
	fmt.Println(s)
	news = append(news, 80)
	fmt.Println(s)
	arr := [...]int{10, 20, 30, 40, 50}
	sarr := arr[1:3]
	fmt.Println(arr, sarr)
	sarr = append(sarr, 60)
	fmt.Println(arr, sarr)
	sarr = append(sarr, 70)
	fmt.Println(arr, sarr)
	sarr = append(sarr, 80)
	fmt.Println(arr, sarr)
}

func ModofySlice(s []byte) []byte {

	s = append(s, 'a')
	fmt.Println("ModofySlice", s)
	return s
}

func TestSlice1() {
	s := []byte{'1', '2'}
	s = ModofySlice(s)
	fmt.Println(s)
}
