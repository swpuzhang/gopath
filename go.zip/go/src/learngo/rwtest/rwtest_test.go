package rwtest

import "testing"

func TestEven(t *testing.T) {
	if !Even(10) {
		t.Log("10 must be even")
		t.Fail()
	}
}
